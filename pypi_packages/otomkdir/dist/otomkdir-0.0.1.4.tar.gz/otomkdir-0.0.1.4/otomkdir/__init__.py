from otomkdir import otomkdir
